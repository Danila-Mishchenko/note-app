import Button from './Button';
import './NavBar.css';


const NavBar = ({ showSearchBar, handleToggleSearchBar, search, setSearch }) => {
    return (
        <header className="header">
            <nav className="nav">
                <div className="nav__content">
                    {
                        showSearchBar
                            ?
                            <Button
                                type='back'
                                onClick={() => handleToggleSearchBar(false)}
                            />
                            :
                            <div></div>
                    }
                    {
                        showSearchBar
                            ?
                            <input
                                type="text"
                                placeholder='Поиск...'
                                value={search}
                                onChange={(e) => setSearch(e.target.value)}
                            />
                            :
                            <h1>Заметки</h1>
                    }
                    {
                        !showSearchBar
                            ?
                            <Button
                                type='search'
                                onClick={() => handleToggleSearchBar(true)}
                            />
                            :
                            <Button
                                type='close'
                                onClick={() => handleToggleSearchBar(false)}
                            />
                    }
                </div>
            </nav>
        </header>
    );
}

export default NavBar;