
import search from "../../assets/icons/search.png";
import close from "../../assets/icons/close.svg";
import back from "../../assets/icons/back.png";

const Button = ({ type = 'close', onClick }) => {
    return (
        <button onClick={() => onClick()}>
            <img
                src={type == 'close' ? close : type == 'back' ? back : type == 'search' ? search : close}
                alt=""
            />
        </button>
    );
}

export default Button;