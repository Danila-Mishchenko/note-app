import './Dialog.css';

const Dialog = ({
    showModal,
    setShowModal,
    editMode,
    addNote,
    title,
    setTitle,
    content,
    setContent,
}) => {

    if (!showModal) {
        return;
    }

    return (
        <div className="dialog">
            <div className="dialog__modal">
                <h3>{editMode ? 'Изменить заметку' : 'Добавить заметку'}</h3>
                <div className="dialog__modal-input">
                    <span>Заголовок</span>
                    <input
                        type="text"
                        placeholder='Заголовок'
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                    />
                </div>
                <div className="dialog__modal-input">
                    <span>Заметка</span>
                    <input
                        type="text"
                        placeholder='Заметка'
                        value={content}
                        onChange={(e) => setContent(e.target.value)}
                    />
                </div>

                <div className="dialog__modal-cotrol">
                    <button
                        onClick={() => setShowModal(false)}>
                        Отмена
                    </button>
                    {
                        editMode
                            ?
                            <button>Изменить</button>
                            :
                            <button onClick={() => addNote()}>Добавить</button>
                    }
                </div>

            </div>
        </div>
    );
}

export default Dialog;