import NoteListItem from "./NoteListItem";

const NoteList = ({ grid, handleShowEditMode, notes, deleteNote }) => {
    return (
        <section className={`note__list container ${!grid ? 'list' : ''}`}>

            {
                notes?.map(note => (
                    <NoteListItem
                        key={note.id}
                        note={note}
                        grid={grid}
                        handleShowEditMode={handleShowEditMode}
                        deleteNote={deleteNote}
                    />
                ))
            }


        </section>
    );
}

export default NoteList;