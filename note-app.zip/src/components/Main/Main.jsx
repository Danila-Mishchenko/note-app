import MainHeader from "./MainHeader";
import NoteList from "./NoteList";
import './main.css';
const Main = ({ grid, hadleGridShow, handleShowEditMode, notes, deleteNote }) => {
    return (
        <main className="main">
            <MainHeader grid={grid} hadleGridShow={hadleGridShow}
            />
            <NoteList
                grid={grid}
                handleShowEditMode={handleShowEditMode}
                notes={notes}
                deleteNote={deleteNote}
            />
        </main>
    )
}

export default Main;