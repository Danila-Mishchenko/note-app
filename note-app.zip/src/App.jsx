import { useState } from "react";
import NavBar from "./components/NavBar/NavBar";
import Main from "./components/Main/Main";
import AddNoteBtn from "./components/AddNoteBtn/AddNoteBtn";
import Dialog from "./components/Dialog/Dialog";
import { v4 as uuidv4 } from 'uuid';

const App = () => {

  const [showSearchBar, setShowSearchBar] = useState(false);
  const [grid, setGrid] = useState(false);

  const [showModal, setShowModal] = useState(false);
  const [editMode, setEditMode] = useState(false);

  const [notes, setNotes] = useState([]);

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  const [search, setSearch] = useState('');

  const handleShowEditMode = () => {
    setEditMode(true);
    setShowModal(true);
  }

  const handleToggleSearchBar = (value) => {
    setShowSearchBar(value);
  }

  const hadleGridShow = () => {
    setGrid((prev) => !prev);
  }

  const hadleShowDialog = () => {
    setEditMode(false);
    setShowModal(true);
  }

  const addNote = () => {
    const note = {
      id: uuidv4(),
      title: title ? title : 'Нет заголовка',
      content: content ? content : 'Нет заметки',
      date: new Date().toLocaleDateString(),
    }
    setNotes([...notes, note]);
    setEditMode(false);
    setShowModal(false);
    clearController();
  }

  const deleteNote = (id) => {
    const index = notes.findIndex(note => note.id === id);
    notes.splice(index, 1);
    setNotes([...notes]);
  }

  const clearController = () => {
    setTitle('');
    setContent('');
  }

  const filteredNotes = search ? notes.filter(note => note.title.includes(search)) : notes;

  return (
    <>
      <NavBar showSearchBar={showSearchBar}
        handleToggleSearchBar={handleToggleSearchBar}
        search={search}
        setSearch={setSearch}
      />
      <Main
        grid={grid}
        hadleGridShow={hadleGridShow}
        handleShowEditMode={handleShowEditMode}
        notes={filteredNotes}
        deleteNote={deleteNote}
      />
      <AddNoteBtn setShowModal={hadleShowDialog} />
      <Dialog
        showModal={showModal}
        setShowModal={setShowModal}
        editMode={editMode}
        addNote={addNote}
        title={title}
        setTitle={setTitle}
        content={content}
        setContent={setContent}
      />
    </>
  )
}

export default App;